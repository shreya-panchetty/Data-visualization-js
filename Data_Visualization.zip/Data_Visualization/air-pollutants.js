function airPollutants()
{
   // Name for the visualisation to appear in the menu bar.
    this.name = 'Air Pollution:1980-2018';

    // Each visualisation must have a unique ID with no special
    // characters.
    this.id = 'air-pollution';
    
    //Property to represent whether data has been loaded.
    this.loaded= false;
    
     var data;
    //Preload the data.This Function is called automatically by the gallery when a visualisation is added.
    this.preload = function() 
    {
    var self = this;
    data = loadTable(
      './data/air-pollution/air_pollution.csv', 'csv', 'header',
      // Callback function to set the value this.loaded to true.
      function(table) {
        self.loaded = true;
      });
    }
    
    //initialising the variables
    var bubbles = [];
    var maxAmt;
    var years = [];
    var selectedYear = 0;
      
   this.setup=function()
   {
	    //initialising the variables to get data from rows and columns 
        var rows = data.getRows();
        var numColumns = data.getColumnCount();
        var yearButtons = [];
        
        //initialising the variables to get the year buttons
        var yearsRow1=630;
        var yearsRow2=10;
        //iterating over columns
        for(var k= 1; k < numColumns; k++)
        {
            var a = data.columns[k];
            years.push(a);
            this.select = createButton(a,a,a)
            this.select.elt.name=a;
            this.select.elt.id=a;
            this.select.position(yearsRow1/2,yearsRow2);
             
            yearsRow1=yearsRow1+96;
            if(k == 20)
            {
                yearsRow2=yearsRow2+25;   
                 yearsRow1=650;
            };
             
            this.select.parent('years')
            this.select.mousePressed(function() {
               changeYear(this.elt.value);
            })
            yearButtons.push(b);
            yearButtons=[];
      }
        
        //function to change year
        function changeYear(year)
        {
            var y = years.indexOf(year);
            selectedYear=y;
            //Iterating over bubble to data of the year pressed
            for(var k= 0; k< bubbles.length; k++)
            {
                bubbles[k].setData(y);
                
            }
        
        }

        bubbles=[];
        maxAmt = 0;
        
        //iterating over the rows
        for(var k= 0; k < rows.length; k++)
        {
            if(rows[k].get(0) != "")
            {
                var b = new this.Bubble(rows[k].get(0));

                for(var j = 1; j < numColumns; j++)
                {
                    if(rows[k].get(j) != "")
                    {
                        var p = rows[k].getNum(j);
                        if(p > maxAmt)
                        {
                            maxAmt = p; //keep a tally of the highest value
                        }
                        b.data.push(p);
                    }
                    else
                    {
                         b.data.push(0);
                    }

                }

                bubbles.push(b);
            }

        }

        for(var k = 0; k< bubbles.length; k++)
        {
            bubbles[k].setData(0);
        }

    }
    //To destroy the year buttons from appearing in the other visulization
   this.destroy = function() {
        var numColumns = data.getColumnCount();
        for(var k= 1; k < numColumns; k++)
        {
            var y = data.columns[k];
            var elem = document.getElementById(y);
            elem.parentNode.removeChild(elem);
 
        }
     };

    this.draw=function()
    {
         //background color
        background(251, 238, 230);

        translate(width/2, height/2);
         //iteratin over the bubbles to updat e and draw the bubble when the year changes
        for(var k= 0; k< bubbles.length; k++)
        {
            bubbles[k].update(bubbles);
            bubbles[k].drawing();
        }
    }
     
      this.Bubble=function(_name)
    {
           //initialising the variables
        this.size = 20;
        this.target_size = 20;
        this.pos = createVector(0,0);
        this.direction = createVector(0,0);
        this.name = _name;
        this.color = color(random(0,255), random(0,255), random(0,255));
        this.data = [];

        this.drawing = function()
        {
             //text and colour of the bubbles
            push();
            textAlign(CENTER);
            noStroke();
            fill(this.color);
            var colyear=0;
            ellipse(this.pos.x, this.pos.y, this.size);
            fill(0);
            text(this.name,this.pos.x,this.pos.y);
            text(this.data[selectedYear],this.pos.x+20,this.pos.y+20);
            pop();
        }

        this.update = function(_bubbles)
        {
             //initial postion of the bubble
            this.direction.set(0,0);

            for(var k= 0; k < _bubbles.length; k++)
            {
                if(_bubbles[k].name != this.name)
                {
                    var v = p5.Vector.sub(this.pos,_bubbles[k].pos); 
                    var dir = v.mag();
                    //to change the direction of the bubble depensing on the magnitude of the bubble
                    if(dir< this.size/2 + _bubbles[k].size/2)
                    {
                        if(dir > 0)
                        {

                            this.direction.add(v)
                        }
                        else
                        {
                            this.direction.add(p5.Vector.random2D());    

                        }
                    }
                }
            }

            this.direction.normalize();
            this.direction.mult(2);
            this.pos.add(this.direction);

            if(this.size < this.target_size)
            {
                this.size += 1;
            }
            else if(this.size > this.target_size)
            {
                this.size -= 1;
            }

        }

        this.setData = function(i)
        {
             //Change the data in the bubble as the year changes
            this.target_size = map(this.data[i], 0, maxAmt, 20, 250);
        }

    }

}