
// Global variable to store the gallery object. The gallery object is
// a container for all the visualisations.
var gallery;
var c;
function setup() {
  // Create a canvas to fill the content div from index.html.
   c = createCanvas(1024, 576);
  c.parent('app');

  // Create a new gallery object.
  gallery = new Gallery();

  // Add the visualisation objects here.
  gallery.addVisual(new TechDiversityRace());
  gallery.addVisual(new TechDiversityGender());
  gallery.addVisual(new PayGapByJob2017());
  gallery.addVisual(new PayGapTimeSeries());
  gallery.addVisual(new ClimateChange());
  gallery.addVisual(new onlineActivities2019());
  gallery.addVisual(new airPollutants());
  gallery.addVisual(new forestedArea());
}

function draw() {
  background(255);
  if (gallery.selectedVisual != null) {
    gallery.selectedVisual.draw();
  }
}
function mousePressed(){
    //console.log(gallery);
    
    if (gallery.selectedVisual == null) {
        return;
    }
    
    if(gallery.selectedVisual.hasOwnProperty("mousePressed")){
        gallery.selectedVisual.mousePressed();
    }
}

function mouseReleased(){
    
    if (gallery.selectedVisual == null) {
        return;
    }
    
    if(gallery.selectedVisual.hasOwnProperty("mouseReleased")){
        gallery.selectedVisual.mouseReleased();
    }
}

function mouseDragged(){
    if (gallery.selectedVisual == null) {
        return;
    }
    
    if(gallery.selectedVisual.hasOwnProperty("mouseDragged")){
        gallery.selectedVisual.mouseDragged();
    }
}

