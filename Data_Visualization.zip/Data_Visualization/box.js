function Box(x,y,width,height,category)
{
    //initialising the variables
    this.x=x;
    this.y=y;
    this.height=height;
    this.width=width;
    this.category = category;
    
    this.mouseOver = function(mouseX, mouseY){
         //to check whether the postion of mouse
        if(mouseX>x && mouseX<x+width && mouseY > y && mouseY<y+height){
            return this.category.name;
        }
        return false;
    }
    
    this.draw= function(){
        fill(category.colour);
        rect(x,y,width,height);
    
    }
}