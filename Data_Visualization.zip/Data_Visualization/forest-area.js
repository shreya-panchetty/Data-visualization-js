function forestedArea()
{
     //code is adapted from the following source:
     //https://github.com/cvalenzuela/Mappa/tree/master/examples/tile/Leaflet
     
     
  // Name for the visualisation to appear in the menu bar.
  this.name = 'Forest Area';

  // Each visualisation must have a unique ID with no special characters.
  this.id = 'forest-area';
    
    //Property to represent whether data has been loaded.
    this.loaded= false;
        
         var worldMap;
         const mappa = new Mappa('Leaflet');
        var canvas;

     
      var properties = {
      lat: 0,
      lng: 0,
      zoom: 2,
      style: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png'};
     
    
    //Preload the data.This Function is called automatically by the gallery when a visualisation is added.
    this.preload=function()
    {
        var self = this;
    data = loadTable(
      './data/forest-area/forest-area.csv', 'csv', 'header',
      // Callback function to set the value this.loaded to true.
      function(table) {
        self.loaded = true;
      });
    }

    
       this.setup=function()
         {
        select("#stage").html("<div id='map_draw'></div><canvas id='map'></canvas>");
        var c = createCanvas(1024, 576);
        c.parent('#map_draw');        
        canvas = select("#map");
           
          // Create a tile map and overlay the canvas on top.
    
          worldMap= mappa.tileMap(properties);
           worldMap.overlay(canvas);

        }
    
        // The draw loop is fully functional but we are not using it for now.
        this.draw=function() 
        {
           
//           // Only redraw the forest when the map change and not every frame.
            worldMap.onChange(this.onMapChange)
//       
        }
        
        //Destroy function to recreate a new cnavas for the other apps
        this.destroy = function() {
        select("#stage").html("<div id='app'></div>");
        //recreate a new canvas for the other app        
             var c = createCanvas(1024, 576);
       c.parent('app');
    };
    
     this.onMapChange = function(){

        //firstChild is #map_draw
        //lastChild is #map
        //put the #map_draw on top of #map
        select("#stage").elt.firstChild.style.zIndex=2;
        select("#stage").elt.lastChild.style.zIndex=1;
        
        //display the mouse event on #map_draw and pass through the mouse event to the next layer which is #map
        select("#stage").elt.firstChild.style.pointerEvents = "none"; 
        //need to set both #map_draw and #map position to absolute for pointerEvents=none to take effect
        select("#stage").elt.firstChild.style.position = "absolute"; 
        select("#stage").elt.firstChild.style.position = "absolute"; 
        
          //clear the canvas to plot the points
        clear();
        
        for (var i = 0; i <data.getRowCount(); i++) {
            //Initialising the variables to get the latitude and longitude of each country
            var latitude = Number(data.getString(i, 'latitude'));
            var longitude = Number(data.getString(i, 'longitude'));
              //To get the map bounds and the correct position to draw the ellipse.
            if (worldMap.map.getBounds().contains({lat: latitude, lng: longitude})) {
              // Transform lat/lng to pixel position
              var position = worldMap.latLngToPixel(latitude, longitude);
                // To get the maximum forest area value and mapping it
              var points = data.getString(i, 'forest-area(%)');
              points = map(points,0, 100, 0, 50) + worldMap.zoom();
               fill(34,139,34);	
          stroke(20);
              ellipse(position.x, position.y, points,points);
                
            }
          }
    }
    
    this.mousePressed = function(){   
    }
    
    
    this.mouseReleased = function(){
    }
    
    this.mouseDragged = function(){
    }
}