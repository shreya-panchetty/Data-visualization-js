function onlineActivities2019()
{
  // Name for the visualisation to appear in the menu bar.
  this.name = 'Online Actvities: 2019';

  // Each visualisation must have a unique ID with no special characters.
  this.id = 'online-activities';
     
    //Title to display above the plot
    this.title='Online Actvities in UK:2019';
    
  var marginSize=35;

  // Layout object to store all common plot layout parameters and methods. 
    this.layout=
    {
       marginSize: marginSize,

        // Margin positions around the plot. Left and bottom have double
        // margin size to make space for axis and tick labels on the canvas.
        leftMargin: marginSize * 2,
        rightMargin: width - marginSize,
        topMargin: marginSize,
        bottomMargin: height - marginSize * 2,
        pad: 5,

        plotWidth: function() {
          return this.rightMargin - this.leftMargin;
        },

        plotHeight: function() {
          return this.bottomMargin - this.topMargin;
        }, 
    }
    //Property to represent whether data has been loaded.
    this.loaded= false;
    
    //Preload the data.This Function is called automatically by the gallery when a visualisation is added.
    this.preload = function() 
    {
    var self = this;
    this.data = loadTable(
      './data/online-activities/online-learningactivities2019.csv', 'csv', 'header',
      // Callback function to set the value this.loaded to true.
      function(table) {
        self.loaded = true;
      });

  };
    
    this.setup =function()
    {
        //font defaults
        textSize(15);
    }
    
    
    this.draw=function()
    {
        if(!this.loaded)
            {
                console.log("not loaded");
                return;
            }
         //initialising the variables
        var waffles = [];
        var ageGroup = ["16-24","25-34","35-44","45-54","55-64","65+"];
        var activities= ['Using public WiFi', 'Providing personal information to social or professional network services', 'Downloading software or apps', 'Ordering or buying goods or services','Internet banking', 'Communicating with public services local councils or government organisations']
        
        //Iterate over ageGroup to postion the waffles repsectively.
        for(var i=0;i<ageGroup.length;i++)
        {
            //First row of waffle data
            if(i<3)
            {
                var w=new Waffle(width/10+(i*220),this.layout.topMargin*2.5,200,200,10,10,this.data,ageGroup[i],activities);
                waffles.push(w); 
            }
            //Second row of waffle data
            else
            {               
                var w=new Waffle(width/10+((i-3)*220),this.layout.topMargin*10,200,200,10,10,this.data,ageGroup[i],activities);
                waffles.push(w);
            }
        
        }

        //Colour of the canvas.
        background(255);
        
        //Iterating  over waffles and draw it on the canvas.
        for(var i=0;i<waffles.length ;i++)
            {
                var w = waffles[i];
                 waffles[i].draw();
            }
        //Iterating over waffle to add labels when mouse hovers over the box in the waffle
        for(var i=0;i<waffles.length;i++)
            {
                var w = waffles[i];
                w.checkMouse(mouseX,mouseY);
            }
        //Calling the functions to appaer in the plot area.
        this.drawTitle()
        this.drawWaffleLabel();
    }
    // Title to apper onn the top of the plot
    this.drawTitle=function()
    {
        fill(0);
        textAlign('center','center');
        text(this.title,this.layout.plotWidth()/2,
             this.layout.topMargin-(this.layout.marginSize/2));
    }
    
    //Function to specify the age group of the each waffle chart.
    this.drawWaffleLabel=function()
    {
        var age=["Ages 16-24","Ages 25-34","Ages 35-44","Ages 45-54","Ages 55-64","Ages 65+"];
        for(var i=0;i<age.length;i++)
            {
                if(i<3)
                    {
                        fill(0);
                        textAlign('center','top');
                        text(age[i],width/5+(i*220),this.layout.topMargin*1.8);
                    }
                else
                    {
                        textAlign('center','top');
                        text(age[i],width/5+((i-3)*220),this.layout.topMargin*9.3);
                    }
            }
    }
}
